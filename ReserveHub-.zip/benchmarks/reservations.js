import { performance } from 'node:perf_hooks';
import { businesses } from '../src/config/businesses.js';
import { addDays } from '../src/utils/dates.js';
import { availableSlots, filterReservations, indexReservations } from '../src/utils/reservations.js';

const business = businesses[0];
const baseDate = '2026-11-25';
const rounds = 30;
let checksum = 0;

function measure(run) {
  for (let warmup = 0; warmup < 5; warmup++) run();
  const timings = [];
  for (let round = 0; round < rounds; round++) {
    const start = performance.now();
    checksum += run();
    timings.push(performance.now() - start);
  }
  timings.sort((first, second) => first - second);
  return ((timings[14] + timings[15]) / 2).toFixed(3);
}

for (const count of [1_000, 10_000]) {
  const records = Array.from({ length: count }, (_, index) => ({
    id: 'SIM-' + index,
    customer: 'Customer ' + index,
    resourceId: business.resources[index % business.resources.length].id,
    date: addDays(baseDate, Math.floor(index / business.resources.length)),
    time: '11:00',
    duration: business.duration,
    partySize: 1,
    status: index % 3 === 0 ? 'Cancelled' : 'Confirmed',
  }));
  const index = indexReservations(records);
  const filters = { date: baseDate, resourceId: '2' };
  const results = {
    indexMs: measure(() => indexReservations(records).byDate.size),
    filterMs: measure(() => filterReservations(records, index, filters).length),
    availabilityMs: measure(() => availableSlots(index, business, 2, baseDate, business.duration).length),
  };
  console.log(count, results);
}
console.log('Checksum:', checksum);
