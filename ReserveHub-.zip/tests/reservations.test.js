import test from 'node:test';
import assert from 'node:assert/strict';
import { businesses } from '../src/config/businesses.js';
import { availableSlots, filterReservations, indexReservations, validateReservation } from '../src/utils/reservations.js';

const [restaurant, salon, sports] = businesses;
const date = '2026-11-25';
const base = {
  id: 'first', customer: 'Olivia Bennett', date, resourceId: 1,
  time: '11:00', duration: 120, partySize: 2, status: 'Confirmed',
};

function validate(overrides, records = [base], excludedId, business = restaurant) {
  const resources = new Map(business.resources.map(resource => [resource.id, resource]));
  return validateReservation({ ...base, ...overrides }, business,
    resources, indexReservations(records), excludedId);
}

test('duplicate reservations are blocked', () => {
  assert.match(validate({}), /already has a reservation/);
});

test('partial overlap is blocked at either end', () => {
  assert.match(validate({ time: '12:45' }), /already has a reservation/);
  assert.match(validate({ time: '11:10' }, [{ ...base, time: '13:00' }]), /already has a reservation/);
});

test('consecutive reservations and separate resource and date buckets are allowed', () => {
  assert.equal(validate({ time: '13:00' }), '');
  assert.equal(validate({}, [{ ...base, time: '13:00' }]), '');
  assert.equal(validate({ resourceId: 2 }), '');
  assert.equal(validate({ date: '2026-11-26' }), '');
});

test('cancellation releases the slot', () => {
  const cancelled = [{ ...base, status: 'Cancelled' }];
  assert.equal(validate({}, cancelled), '');
  assert.equal(availableSlots(indexReservations(cancelled), restaurant, 1, date, 120)[0], '11:00');
});

test('capacity checks include the exact limit, zero, and fractional counts', () => {
  assert.equal(validate({}, []), '');
  for (const partySize of [0, 1.5, 3]) {
    assert.match(validate({ partySize }, []), /customer count/);
  }
});

test('opening and closing limits include an exact closing-time end', () => {
  assert.match(validate({ time: '10:59' }, []), /working hours/);
  assert.match(validate({ time: '21:01' }, []), /working hours/);
  assert.equal(validate({ time: '21:00' }, []), '');
  assert.match(validate({ date: '2026-02-30' }, []), /valid date/);
});

test('editing excludes the current record and still checks every other booking', () => {
  const records = [base, { ...base, id: 'second', time: '13:00' }];
  assert.equal(validate({ customer: 'Olivia Smith' }, records, base.id), '');
  assert.match(validate({ time: '11:15' }, records, base.id), /already has a reservation/);
  const slots = availableSlots(indexReservations(records), restaurant, 1, date, 120, base.id);
  assert.ok(slots.includes('11:00'));
  assert.ok(!slots.includes('11:15'));
});

test('all three business configurations apply the same rule with their own hours and duration', () => {
  for (const business of [restaurant, salon, sports]) {
    const item = { time: business.opens, duration: business.duration, partySize: 1 };
    assert.equal(validate(item, [], undefined, business), '');
    assert.match(validate({ ...item, time: '07:45' }, [], undefined, business), /working hours/);
  }
  assert.match(validate({ time: salon.opens, duration: salon.duration }, [], undefined, salon), /customer count/);
});




test('date and resource filters combine', () => {
  const rows = [base, {...base, id: 'second', resourceId: 2}, {...base, id: 'third', date: '2026-11-26'}];
  assert.deepEqual(filterReservations(rows, indexReservations(rows), {date, resourceId: '1'}), [base]);
});
