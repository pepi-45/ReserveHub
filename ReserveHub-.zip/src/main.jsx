import { useCallback, useMemo, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Icon } from './components/Icon';
import { Layout } from './components/Layout';
import { ReservationForm } from './components/ReservationForm';
import { businesses } from './config/businesses';
import { useHashPage } from './hooks/useHashPage';
import { Dashboard } from './pages/Dashboard';
import { Reservations } from './pages/Reservations';
import { Calendar, Resources, Settings } from './pages/WorkspacePages';
import { localDate } from './utils/dates';
import { indexReservations, validateReservation } from './utils/reservations';
import { createMockReservations } from './data/mockReservations';
import './styles/main.css';

const pages = { dashboard: Dashboard, reservations: Reservations, calendar: Calendar, resources: Resources, settings: Settings };
const byBusiness = new Map(businesses.map(business => [business.id, {
  business,
  resources: new Map(business.resources.map(resource => [resource.id, resource])),
}]));

function App() {
  const page = useHashPage();
  const [businessId, setBusinessId] = useState(businesses[0].id);
  const [records, setRecords] = useState(() => Object.fromEntries(businesses.map(business => [business.id, createMockReservations(business)])));
  const [form, setForm] = useState(null);
  const [notice, setNotice] = useState('');
  const returnFocus = useRef(null);
  const newButton = useRef(null);
  const today = localDate();
  const { business, resources } = byBusiness.get(businessId);
  const reservations = records[businessId];
  const index = useMemo(() => indexReservations(reservations), [reservations]);
  const Page = pages[page.id];

  const openForm = useCallback((item = null) => {
    returnFocus.current = document.activeElement;
    setNotice('');
    setForm({ item });
  }, []);

  function closeForm() {
    setForm(null);
    (returnFocus.current?.isConnected ? returnFocus.current : newButton.current)?.focus();
  }

  const commit = useCallback((updated) => {
    const next = { ...records, [businessId]: updated };
    setRecords(next);
  }, [businessId, records]);

  function save(item, id) {
    const error = validateReservation(item, business, resources, index, id);
    if (error) return error;
    const updated = id
      ? reservations.map(existing => existing.id === id ? { ...item, id } : existing)
      : [{ ...item, id: crypto.randomUUID() }, ...reservations];

    commit(updated);
    setNotice(id ? 'Reservation updated.' : 'Reservation created.');
    return '';
  }

  const cancelReservation = useCallback((item) => {
    const status = 'Cancelled';
    const updated = reservations.map(value => value.id === item.id ? { ...value, status } : value);
    commit(updated);
    setNotice('Reservation cancelled.');
  }, [reservations, commit]);

  return (
    <Layout page={page} business={business} onBusinessChange={id => {
      setBusinessId(id);
      setNotice('');
    }}>
      <div className="page-heading">
        <h1>{page.label}</h1>
        {['dashboard', 'reservations'].includes(page.id) && (
          <button type="button" className="primary" ref={newButton} onClick={() => openForm()}>
            <Icon name="plus" /> New Reservation
          </button>
        )}
      </div>
      <div aria-live="polite" className="announcement">{notice}</div>
      <Page key={page.id + businessId} business={business} resources={resources} index={index}
        reservations={reservations} today={today} onEdit={openForm} onStatus={cancelReservation} />
      {form && (
        <ReservationForm business={business} index={index} reservation={form.item}
          today={today} onSave={save} onClose={closeForm} />
      )}
    </Layout>
  );
}

createRoot(document.getElementById('root')).render(<App />);
