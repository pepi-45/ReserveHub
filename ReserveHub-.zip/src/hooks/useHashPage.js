import { useEffect, useState } from 'react';

export const navigation = [
  { id: 'dashboard', label: 'Dashboard', icon: 'dashboard' },
  { id: 'reservations', label: 'Reservations', icon: 'book' },
  { id: 'calendar', label: 'Calendar', icon: 'calendar' },
  { id: 'resources', label: 'Resources', icon: 'layers' },
  { id: 'settings', label: 'Settings', icon: 'settings' },
];

function readPage() {
  return navigation.find(({ id }) => window.location.hash === '#/' + id) ?? navigation[0];
}

export function useHashPage() {
  const [page, setPage] = useState(readPage);

  useEffect(() => {
    function update() {
      setPage(readPage());
      window.scrollTo(0, 0);
    }
    window.addEventListener('hashchange', update);
    return () => window.removeEventListener('hashchange', update);
  }, []);

  return page;
}
