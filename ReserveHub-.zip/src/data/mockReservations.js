import { addDays, localDate, toMinutes, toTime, weekStart } from '../utils/dates.js';

const slots = [
  [0, 1, 0, 'Confirmed', 'Olivia Bennett'], [0, 3, 6, 'Confirmed', 'James Carter'],
  [1, 2, 1, 'Confirmed', 'Sofia Martinez'], [2, 3, 0, 'Confirmed', 'Ethan Brooks'],
  [2, 4, 4, 'Confirmed', 'Mia Collins'], [2, 1, 7, 'Confirmed', 'Noah Patel'],
  [3, 4, 2, 'Confirmed', 'Amelia Reed'], [3, 2, 6, 'Cancelled', 'Lucas Chen'],
  [4, 1, 1, 'Confirmed', 'Isabella Young'], [4, 5, 7, 'Confirmed', 'Leo Morgan'],
  [5, 2, 3, 'Confirmed', 'Charlotte Hill'], [6, 3, 1, 'Confirmed', 'Mason Lee'],
];

export function createMockReservations(business, today = localDate()) {
  const monday = weekStart(today);
  return slots.map(([day, resourceId, offset, status, customer], index) => ({
    id: 'RH-' + (1001 + index),
    customer, resourceId, status,
    date: addDays(monday, day),
    time: toTime(toMinutes(business.opens) + offset * 60),
    duration: business.duration,
    partySize: 1,
  })).reverse();
}
