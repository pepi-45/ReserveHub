import { memo } from 'react';
import { formatDate } from '../utils/dates';
import { Icon } from './Icon';

export const ReservationsTable = memo(function ReservationsTable({
  resources, reservations, preview = false, onEdit, onStatus,
}) {
  return (
    <section className="panel" aria-labelledby="reservation-list-title">
      <div className="panel-heading">
        <h2 id="reservation-list-title"><Icon name="book" /> {preview ? 'Recent reservations' : 'Reservation list'}</h2>
        {preview && <a className="button" href="#/reservations">View all</a>}
      </div>
      <div className="table-scroll" tabIndex={0} role="region" aria-labelledby="reservation-list-title">
        <table>
          <thead>
            <tr>
              <th scope="col">Customer</th>
              <th scope="col">Resource</th>
              <th scope="col">Date and time</th>
              <th scope="col">Duration</th>
              <th scope="col">Status</th>
              {!preview && <th scope="col">Actions</th>}
            </tr>
          </thead>
          <tbody>
            {reservations.length === 0 &&
              <tr><td colSpan={preview ? 5 : 6}>No reservations found.</td></tr>}
            {reservations.map(item => (
              <tr key={item.id}>
                <th scope="row">{item.customer}<small>{item.partySize} {item.partySize === 1 ? 'customer' : 'customers'}</small></th>
                <td>{resources.get(item.resourceId)?.name}</td>
                <td>
                  <time dateTime={item.date + 'T' + item.time}>
                    {formatDate(item.date, { month: 'short', day: 'numeric', year: 'numeric' })} · {item.time}
                  </time>
                </td>
                <td>{item.duration} min</td>
                <td><span className={'status ' + item.status.toLowerCase()}>{item.status}</span></td>
                {!preview && (
                  <td>
                    {item.status !== 'Cancelled' && (
                      <div className="row-actions">
                        <button type="button" aria-label={'Edit reservation for ' + item.customer} onClick={() => onEdit(item)}>Edit</button>
                        <button type="button" aria-label={'Cancel reservation for ' + item.customer}
                          onClick={() => onStatus(item)}>Cancel</button>
                      </div>
                    )}
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
});
