import { useEffect, useMemo, useRef, useState } from 'react';
import { availableSlots } from '../utils/reservations';

export function ReservationForm({ business, index, reservation, today, onSave, onClose }) {
  const dialog = useRef(null);
  const [date, setDate] = useState(reservation?.date ?? today);
  const [partySize, setPartySize] = useState(reservation?.partySize ?? 1);
  const [resourceId, setResourceId] = useState(reservation?.resourceId ?? '');
  const [requestedTime, setRequestedTime] = useState(reservation?.time ?? '');
  const [availableOnly, setAvailableOnly] = useState(true);
  const [error, setError] = useState('');
  const duration = reservation?.duration ?? business.duration;

  useEffect(() => {
    dialog.current.showModal();
  }, []);

  const choices = useMemo(() => business.resources
    .filter(resource => resource.capacity >= Number(partySize))
    .map(resource => ({
      ...resource,
      slots: date ? availableSlots(index, business, resource.id, date, duration, reservation?.id) : [],
    }))
    .filter(resource => !availableOnly || resource.slots.length > 0),
  [availableOnly, business, date, duration, index, partySize, reservation]);

  const selected = choices.find(resource => resource.id === resourceId);
  const slots = selected?.slots ?? [];
  const time = slots.includes(requestedTime) ? requestedTime : '';

  function submit(event) {
    event.preventDefault();
    const fields = new FormData(event.currentTarget);
    const message = onSave({
      customer: fields.get('customer').trim(),
      resourceId: selected?.id,
      date, time, duration,
      partySize: Number(partySize),
      status: reservation?.status ?? 'Confirmed',
    }, reservation?.id);

    if (message) setError(message);
    else dialog.current.close();
  }

  return (
    <dialog ref={dialog} onClose={onClose} aria-labelledby="form-title">
      <form onSubmit={submit} onChange={() => setError('')}>
        <h2 id="form-title">{reservation ? 'Edit reservation' : 'New reservation'}</h2>
        <label>Customer name
          <input name="customer" defaultValue={reservation?.customer} autoFocus required maxLength={80} />
        </label>
        <div className="form-row">
          <label>Date<input type="date" value={date} onChange={event => {
            setDate(event.target.value);
            setRequestedTime('');
          }} required /></label>
          <label>Number of customers
            <input type="number" min="1" step="1" value={partySize}
              onChange={event => setPartySize(event.target.value)} required />
          </label>
        </div>
        <label className="check-label">
          <input type="checkbox" checked={availableOnly} onChange={event => setAvailableOnly(event.target.checked)} />
          Show only resources with available slots
        </label>
        <label>Resource
          <select value={selected?.id ?? ''} onChange={event => {
            setResourceId(Number(event.target.value));
            setRequestedTime('');
          }} required>
            <option value="">{choices.length ? 'Choose a resource' : 'No matching resources'}</option>
            {choices.map(resource => (
              <option key={resource.id} value={resource.id}>{resource.name} · Capacity {resource.capacity}</option>
            ))}
          </select>
        </label>
        <label>Available start times
          <select value={time} onChange={event => setRequestedTime(event.target.value)} required>
            <option value="">{slots.length ? 'Choose a start time' : 'No slots available'}</option>
            {slots.map(slot => <option key={slot}>{slot}</option>)}
          </select>
        </label>
        <p>{business.opens}–{business.closes} · {duration} minutes</p>
        {!choices.length && <p className="error">No resources match the customer count and availability filters.</p>}
        {error && <p className="error" role="alert">{error}</p>}
        <div className="form-actions">
          <button type="button" onClick={() => dialog.current.close()}>Close</button>
          <button type="submit" className="primary" disabled={choices.length === 0}>Save reservation</button>
        </div>
      </form>
    </dialog>
  );
}
