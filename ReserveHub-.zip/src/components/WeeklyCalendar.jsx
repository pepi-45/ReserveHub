import { memo, useState } from 'react';
import { addDays, formatDate, weekStart } from '../utils/dates';
import { Icon } from './Icon';

export const WeeklyCalendar = memo(function WeeklyCalendar({ resources, index, today }) {
  const [start, setStart] = useState(() => weekStart(today));
  const dates = Array.from({ length: 7 }, (_, day) => addDays(start, day));
  const range = formatDate(start, { month: 'short', day: 'numeric', year: 'numeric' }) +
    ' – ' + formatDate(dates[6], { month: 'short', day: 'numeric', year: 'numeric' });

  return (
    <section className="panel" aria-labelledby="week-title">
      <div className="panel-heading">
        <div>
          <h2 id="week-title"><Icon name="calendar" /> Weekly calendar</h2>
          <p aria-live="polite">{range}</p>
        </div>
        <div className="week-controls">
          <button type="button" onClick={() => setStart(addDays(start, -7))}>Previous</button>
          <button type="button" onClick={() => setStart(weekStart(today))}>Today</button>
          <button type="button" onClick={() => setStart(addDays(start, 7))}>Next</button>
        </div>
      </div>
      <div className="calendar-grid">
        {dates.map(date => {
          const bookings = [...(index.byDate.get(date) ?? [])]
            .sort((first, second) => first.time.localeCompare(second.time));

          return (
            <section className="calendar-day" key={date}>
              <h3>
                <span>{formatDate(date, { weekday: 'short' })}</span>
                <time dateTime={date} aria-current={date === today ? 'date' : undefined}>
                  {formatDate(date, { day: 'numeric' })}
                </time>
              </h3>
              {bookings.length ? (
                <ul>
                  {bookings.map(item => (
                    <li className={'event ' + item.status.toLowerCase()} key={item.id}>
                      <strong>{resources.get(item.resourceId)?.name}</strong>
                      <span>{item.time} · {item.status}</span>
                      <span>{item.customer}</span>
                    </li>
                  ))}
                </ul>
              ) : <p className="empty-day">No bookings</p>}
            </section>
          );
        })}
      </div>
    </section>
  );
});
