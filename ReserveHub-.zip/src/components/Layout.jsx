import { useState } from 'react';
import { businesses } from '../config/businesses';
import { navigation } from '../hooks/useHashPage';
import { Icon } from './Icon';

export function Layout({ page, business, onBusinessChange, children }) {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="shell">
      <a className="skip" href="#main-content" onClick={event => {
        event.preventDefault();
        document.getElementById('main-content').focus();
      }}>Skip to content</a>
      <aside className="sidebar">
        <div className="sidebar-top">
          <a className="brand" href="#/dashboard" onClick={() => setMenuOpen(false)}>
            <span className="brand-icon"><Icon name="calendar" /></span>
            ReserveHub
          </a>
          <button className="menu-toggle" type="button" aria-expanded={menuOpen}
            aria-controls="primary-navigation" onClick={() => setMenuOpen(!menuOpen)}>
            <Icon name="menu" /> Menu
          </button>
        </div>
        <nav id="primary-navigation" className={menuOpen ? 'nav open' : 'nav'} aria-label="Main">
          {navigation.map(item => (
            <a key={item.id} href={'#/' + item.id}
              aria-current={page.id === item.id ? 'page' : undefined}
              onClick={() => setMenuOpen(false)}>
              <Icon name={item.icon} /> {item.label}
            </a>
          ))}
        </nav>
      </aside>
      <div className="workspace">
        <header className="topbar">
          <span className="breadcrumb"><Icon name={page.icon} /> {page.label}</span>
          <label className="business-picker">
            <span>Business</span>
            <select value={business.id} onChange={event => onBusinessChange(event.target.value)}>
              {businesses.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}
            </select>
          </label>
        </header>
        <main id="main-content" tabIndex={-1}>{children}</main>
      </div>
    </div>
  );
}
