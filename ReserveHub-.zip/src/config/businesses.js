function makeResources(names, capacities) {
  return names.map((name, index) => ({ id: index + 1, name, capacity: capacities[index] }));
}

export const businesses = [
  {
    id: 'restaurant', name: 'Restaurant', resourceLabel: 'Tables',
    opens: '11:00', closes: '23:00', duration: 120, slotInterval: 15, capacityMode: 'Variable capacity',
    resources: makeResources(
      ['Table 1', 'Table 2', 'Table 3', 'Table 4', 'Table 5', 'Table 6', 'Table 7', 'Table 8'],
      [2, 4, 4, 6, 6, 8, 4, 2],
    ),
  },
  {
    id: 'salon', name: 'Hair Salon', resourceLabel: 'Stylists',
    opens: '09:00', closes: '19:00', duration: 30, slotInterval: 15, capacityMode: 'One customer per stylist',
    resources: makeResources(['Avery', 'Morgan', 'Riley', 'Jamie', 'Sasha'], [1, 1, 1, 1, 1]),
  },
  {
    id: 'sports', name: 'Sports Center', resourceLabel: 'Sports courts',
    opens: '08:00', closes: '22:00', duration: 60, slotInterval: 15, capacityMode: 'Variable capacity',
    resources: makeResources(
      ['Court 1', 'Court 2', 'Court 3', 'Court 4', 'Court 5', 'Court 6'], [2, 4, 4, 6, 10, 12],
    ),
  },
];
