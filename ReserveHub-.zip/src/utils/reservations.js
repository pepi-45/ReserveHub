import { toMinutes, toTime, validDate } from './dates.js';

function addToGroup(groups, key, value) {
  if (!groups.has(key)) groups.set(key, []);
  groups.get(key).push(value);
}

function resourceDate(resourceId, date) {
  return resourceId + '/' + date;
}

export function indexReservations(records) {
  const byDate = new Map();
  const activeByResourceDate = new Map();

  for (const item of records) {
    addToGroup(byDate, item.date, item);
    if (item.status === 'Cancelled') continue;
    const start = toMinutes(item.time);
    addToGroup(activeByResourceDate, resourceDate(item.resourceId, item.date), {
      id: item.id, start, end: start + item.duration,
    });
  }
  return { byDate, activeByResourceDate };
}

function activeOn(index, resourceId, date) {
  return index.activeByResourceDate.get(resourceDate(resourceId, date)) ?? [];
}

function overlaps(blocks, start, end, excludedId) {
  return blocks.some(block => block.id !== excludedId && start < block.end && block.start < end);
}

export function validateReservation(item, business, resources, index, excludedId) {
  if (!item.customer.trim()) return 'Enter a customer name.';
  const resource = resources.get(item.resourceId);
  if (!resource) return 'Select a resource.';
  if (!Number.isInteger(item.partySize) || item.partySize < 1 || item.partySize > resource.capacity) {
    return 'Enter a customer count from 1 to ' + resource.capacity + ' for this resource.';
  }
  if (!validDate(item.date)) return 'Choose a valid date.';
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(item.time)) return 'Choose a valid start time.';
  const start = toMinutes(item.time);
  const end = start + item.duration;
  if (!Number.isInteger(item.duration) || item.duration < 1 ||
      start < toMinutes(business.opens) || end > toMinutes(business.closes)) {
    return 'The reservation must fit within working hours (' + business.opens + '–' + business.closes + ').';
  }
  if (overlaps(activeOn(index, item.resourceId, item.date), start, end, excludedId)) {
    return 'This resource already has a reservation during that time.';
  }
  return '';
}

export function availableSlots(index, business, resourceId, date, duration, excludedId) {
  const blocks = activeOn(index, resourceId, date);
  const opening = toMinutes(business.opens);
  const latestStart = toMinutes(business.closes) - duration;
  const slots = [];
  for (let start = opening; start <= latestStart; start += business.slotInterval) {
    if (!overlaps(blocks, start, start + duration, excludedId)) slots.push(toTime(start));
  }
  return slots;
}

export function filterReservations(records, index, { date, resourceId }) {
  const candidates = date ? index.byDate.get(date) ?? [] : records;
  return candidates.filter(item => !resourceId || item.resourceId === Number(resourceId));
}

