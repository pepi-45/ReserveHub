import { useMemo, useState } from 'react';
import { WeeklyCalendar } from '../components/WeeklyCalendar';
import { Icon } from '../components/Icon';
import { availableSlots } from '../utils/reservations';

export function Calendar({ resources, index, today }) {
  return <WeeklyCalendar resources={resources} index={index} today={today} />;
}

export function Resources({ business, index, today }) {
  const [date, setDate] = useState(today);
  const [capacity, setCapacity] = useState('');
  const [availableOnly, setAvailableOnly] = useState(false);

  const rows = useMemo(() => business.resources
    .filter(resource => resource.capacity >= Number(capacity))
    .map(resource => ({
      ...resource,
      slots: date ? availableSlots(index, business, resource.id, date, business.duration).length : 0,
    }))
    .filter(resource => !availableOnly || resource.slots > 0),
  [business, index, date, capacity, availableOnly]);

  return (
    <section className="panel inventory" aria-labelledby="inventory-title">
      <div className="panel-heading"><h2 id="inventory-title">{business.resourceLabel}</h2></div>
      <div className="filters">
        <label>Date<input type="date" value={date} onChange={event => setDate(event.target.value)} /></label>
        <label>Minimum capacity<input type="number" min="1" step="1" value={capacity}
          onChange={event => setCapacity(event.target.value)} /></label>
        <label className="check-label">
          <input type="checkbox" checked={availableOnly} onChange={event => setAvailableOnly(event.target.checked)} />
          Available resources only
        </label>
      </div>
      {rows.length === 0 && <p className="no-results">No resources match your filters.</p>}
      <ul className="resource-grid">
        {rows.map(resource => (
          <li key={resource.id}>
            <span className="metric-icon blue"><Icon name="layers" /></span>
            <h3>{resource.name}</h3>
            <p>Capacity {resource.capacity}</p>
            {date && <p>{resource.slots} available start {resource.slots === 1 ? 'time' : 'times'}</p>}
          </li>
        ))}
      </ul>
    </section>
  );
}

const themes = [
  { id: 'default', label: 'Default' },
  { id: 'dark', label: 'Dark' },
  { id: 'soft-pink', label: 'Soft Pink' },
  { id: 'emerald', label: 'Emerald' },
];

export function Settings({ business }) {
  const [theme, setTheme] = useState(() => document.documentElement.dataset.theme);

  function selectTheme(id) {
    document.documentElement.dataset.theme = id;
    setTheme(id);
  }

  return (
    <>
      <section className="panel" aria-labelledby="settings-title">
        <div className="panel-heading"><h2 id="settings-title">Business configuration</h2></div>
        <dl className="settings-list">
          <div><dt>Business</dt><dd>{business.name}</dd></div>
          <div><dt>Resource type</dt><dd>{business.resourceLabel}</dd></div>
          <div><dt>Working hours</dt><dd>{business.opens}–{business.closes}</dd></div>
          <div><dt>Default duration</dt><dd>{business.duration} minutes</dd></div>
          <div><dt>Capacity rule</dt><dd>{business.capacityMode}</dd></div>
        </dl>
      </section>
      <section className="panel" aria-labelledby="theme-title">
        <div className="panel-heading"><h2 id="theme-title">Theme</h2></div>
        <div className="theme-options" role="radiogroup" aria-labelledby="theme-title">
          {themes.map(option => (
            <label className="theme-card" key={option.id}>
              <input type="radio" name="theme" value={option.id} checked={theme === option.id}
                onChange={() => selectTheme(option.id)} />
              <span>{option.label}</span>
              <span className={'theme-preview preview-' + option.id} aria-hidden="true">
                <span /><span /><span /><span />
              </span>
            </label>
          ))}
        </div>
      </section>
    </>
  );
}
