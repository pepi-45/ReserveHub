import { useMemo } from 'react';
import { ReservationsTable } from '../components/ReservationsTable';
import { WeeklyCalendar } from '../components/WeeklyCalendar';

export function Dashboard({ resources, index, reservations, today }) {
  const recent = useMemo(() => reservations.slice(0, 5), [reservations]);
  return (
    <>
      <WeeklyCalendar resources={resources} index={index} today={today} />
      <ReservationsTable resources={resources} reservations={recent} preview />
    </>
  );
}
