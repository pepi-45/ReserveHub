import { useMemo, useState } from 'react';
import { ReservationsTable } from '../components/ReservationsTable';
import { filterReservations } from '../utils/reservations';

const empty = { date: '', resourceId: '' };
const pageSize = 25;

export function Reservations({ business, resources, reservations, index, onEdit, onStatus }) {
  const [filters, setFilters] = useState(empty);
  const [page, setPage] = useState(1);
  const matches = useMemo(() => filterReservations(reservations, index, filters),
    [reservations, index, filters]);
  const pages = Math.max(1, Math.ceil(matches.length / pageSize));
  const current = Math.min(page, pages);
  const rows = useMemo(() => matches.slice((current - 1) * pageSize, current * pageSize),
    [matches, current]);

  function change(event) {
    const { name, value } = event.target;
    setFilters(previous => ({ ...previous, [name]: value }));
    setPage(1);
  }

  return (
    <>
      <form className="filters panel" aria-label="Filter reservations" onSubmit={event => event.preventDefault()}>
        <label>Date<input type="date" name="date" value={filters.date} onChange={change} /></label>
        <label>Resource<select name="resourceId" value={filters.resourceId} onChange={change}>
          <option value="">All resources</option>
          {business.resources.map(resource => <option key={resource.id} value={resource.id}>{resource.name}</option>)}
        </select></label>
        <button type="button" onClick={() => {
          setFilters(empty);
          setPage(1);
        }}>Clear filters</button>
      </form>
      <ReservationsTable resources={resources} reservations={rows} onEdit={onEdit} onStatus={onStatus} />
      {pages > 1 && (
        <nav className="pagination" aria-label="Reservation pages">
          <button type="button" disabled={current === 1} onClick={() => setPage(current - 1)}>Previous</button>
          <span>Page {current} of {pages}</span>
          <button type="button" disabled={current === pages} onClick={() => setPage(current + 1)}>Next</button>
        </nav>
      )}
    </>
  );
}
